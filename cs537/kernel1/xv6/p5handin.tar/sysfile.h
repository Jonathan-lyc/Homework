void updatecount(int syscall);
