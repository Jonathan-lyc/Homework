extern "C"
int yywrap()
{
  return 1;
}
